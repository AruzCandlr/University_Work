/*  The structure of Triangle class is similar to Rectangle */
public class Triangle extends Shape {

	//TODO: Code Here

}
