/*
 * The Rectangle class, subclass of Shape
 */
public class Rectangle extends Shape {
	// Private member variables
	// TODO: CODE HERE

	// Constructors
	public Rectangle() {
		// TODO: CODE HERE
	}

	public Rectangle(String color, double length, double width) {
		// TODO: CODE HERE
	}

	@Override
	public String toString() {
		// TODO: CODE HERE
		return "";
	}

	// Override the inherited getArea() to provide the proper implementation
	@Override
	public double getArea() {
		// TODO: CODE HERE
		return 0.0;
	}

	public double getArea(double length, double width) {
		// TODO: CODE HERE
		return 0.0;
	}
}
