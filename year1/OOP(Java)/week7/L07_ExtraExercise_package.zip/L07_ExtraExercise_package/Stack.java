import java.util.ArrayList;

public class Stack<E> extends ArrayList<E>{
	
	//your code here
}
