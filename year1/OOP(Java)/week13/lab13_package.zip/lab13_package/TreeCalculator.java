
public class TreeCalculator {

	// You may create any helper methods if needed
	
	public static int findMax(Node root)
	{	//****YOUR CODE HERE**
		return -1;
		//*********************
	}
	
	
	public static int findMin(Node root)
	{	//****YOUR CODE HERE**
		return -1;
		//*********************
	}
	
	
	
	//************* TASK A BONUS ****************//
	// You may create any helper methods if needed
	
	
	public static double sumTree(Node root)
	{	
		//****YOUR CODE HERE**
		return -1;
		//*********************
	}
	
	public static double avgTree(Node root)
	{
		//****YOUR CODE HERE**
		return -1;
		//*********************
	}
	
	
	
	
	//************* TASK B BONUS ****************//
	// You may create any helper methods if needed
	
	public static boolean isFullBinaryTree(Node root)
	{	
		//****YOUR CODE HERE**
		return false;
		//*********************
		
	}
	
	public static boolean isBinarySearchTree(Node root)
	{
		//****YOUR CODE HERE**
		return false;
		//*********************
		
	}
	
}
