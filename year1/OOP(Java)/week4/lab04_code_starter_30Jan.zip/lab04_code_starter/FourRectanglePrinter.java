// Complete this file to construct a rectangle and translate it three times to form one large rectangle

// File: <NAME OF FILE>
// Description: <A DESCRIPTION OF YOUR PROGRAM>
// Assignment Number: <e.g., 1 – 13>
//
// ID: <YOUR STUDENT ID>
// Name: <YOUR FULLNAME>
// Section: <YOUR SECTION e.g., 1, 2, or 3>
// Grader: <YOUR GRADER’S NAME>
//
// On my honor, <YOUR FULLNAME>, this lab assignment is my own work
// and I have not provided this code to any other students.

import java.awt.Rectangle;

public class FourRectanglePrinter {

	public static void main(String[] args) {
		// YOUR CODE GOES HERE
		
		// Complete this line to constructuct "box" variable with type Rectangle
		Rectangle box;
		
		// Print box information using println method
		System.out.println(box);
		
		// Call translate method to move the box and print the box information after each move
		// Repeate thses steps three times to form a large rectangle

	}

}
