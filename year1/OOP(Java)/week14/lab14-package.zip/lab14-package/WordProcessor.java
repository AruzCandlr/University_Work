import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;

public class WordProcessor {

  /**
   * this method will accept a file name as a parameter, read the textual content in a given file, and return these words in a list of strings. 
   */
	public static ArrayList<String> readFile (String file) throws FileNotFoundException {
    ArrayList<String> words = new ArrayList<String>();
		Scanner in = new Scanner(new File(file));
    while(in.hasNext()){
      String word = in.next();
      words.add(word);
    }
		return words;
	}

  /**
   * this method will accept a list of strings and print out all the words separated by commas in one line.  
   */
	public static void printWords(ArrayList<String> words){
    System.out.println(Arrays.toString(words.toArray()));
	}
	
	public static void sort (ArrayList<String>  a) {
    // TODO 1: implement sort method that accepts an array list of string, then sort it in descending order (b comes before a) using one of the sorting algorithms discusses in class. 
		
    
	}


  public static void removeDuplicate(ArrayList<String>  a){
    // TODO 2: implement removeDuplicate method that accepts a list of string, then remove all duplicates from the list
    // e.g., if the list has "ink sort make ink sort ink", then the list should be changed to "sort make ink".
    // Note that the result list may not have the same ordering as the original one.
    
    
  }
}